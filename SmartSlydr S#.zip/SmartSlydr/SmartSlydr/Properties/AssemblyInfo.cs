﻿using System.Reflection;

[assembly: AssemblyTitle("SmartSlydr")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("SmartSlydr")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2023")]
[assembly: AssemblyVersion("1.0.0.*")]

