﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;
using Newtonsoft.Json;
using System.Collections.Generic;
namespace SmartSlydr_Integration
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class SmartSlydr
	{
		#region Declarations
		private static string Username;
		private static string Password;
		private static string Access_Token;
		private static string Refresh_Token;
		private static Debug_Options Debug;
		#endregion

		//****************************************************************************************
		// 
		//  SmartSlydr	-	Default Constructor
		// 
		//****************************************************************************************
		public SmartSlydr()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Username, string Password, short Debug)
		{
			#region Save Parameters
			SmartSlydr.Username = Username;
			SmartSlydr.Password = Password;
			#endregion

			Set_Debug_Message_Output(Debug);

			if (Get_Security_Tokens() == false)
			{
				return 0;
			}

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Get_Security_Tokens	-	Get Access and Security Tokens
		// 
		//****************************************************************************************
		private bool Get_Security_Tokens()
		{
			HttpsClient client = null;

			#region Create url
			//Create url
			string url = "https://34yl6ald82.execute-api.us-east-2.amazonaws.com/prod/auth";
			Debug_Message("Get_Security_Tokens", "URL: " + url);
			#endregion

			#region Create JSON
			string json = "{\"username\":\"" + Username + "\",\"password\":\"" + Password + "\"}";
			Debug_Message("Get_Security_Tokens", "json = " + json);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Get_Security_Tokens", "Error - response.Code = " + response.Code);
					Debug_Message("Get_Security_Tokens", "Error - response.ContentString = " + response.ContentString);
					return false;
				}
				else
				{
					Debug_Message("Get_Security_Tokens", "Success - response.ContentString = " + response.ContentString);
					SmartSlydr.Access_Token = Parse_Data_Substring(response.ContentString, "", "\"access_token\":\"", "\"");
					Debug_Message("Get_Security_Tokens", "Access Token = " + SmartSlydr.Access_Token);
					SmartSlydr.Refresh_Token = Parse_Data_Substring(response.ContentString, "", "\"refresh_token\":\"", "\"");
					Debug_Message("Get_Security_Tokens", "Refresh Token = " + SmartSlydr.Refresh_Token);
					return true;
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "SmartSlydr - Get_Security_Tokens - Error Retreiving Access Tokens" + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return false;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Refresh_Access_Token	-	Get Access and Security Tokens
		// 
		//****************************************************************************************
		private bool Refresh_Access_Token()
		{
			HttpsClient client = null;

			#region Create url
			//Create url
			string url = "https://34yl6ald82.execute-api.us-east-2.amazonaws.com/prod/token";
			Debug_Message("Refresh_Access_Token", "URL: " + url);
			#endregion

			#region Create JSON
			string json = "{\"refresh_token\":\"" + SmartSlydr.Refresh_Token + "\"}";
			Debug_Message("Refresh_Access_Token", "json = " + json);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Header.SetHeaderValue("Access Token", SmartSlydr.Access_Token);
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if ((response.Code < 200) || (response.Code >= 300))
				{
					// server threw a error
					Debug_Message("Refresh_Access_Token", "Error - response.Code = " + response.Code);
					Debug_Message("Refresh_Access_Token", "Error - response.ContentString = " + response.ContentString);
					return false;
				}
				else
				{
					Debug_Message("Refresh_Access_Token", "Success - response.ContentString = " + response.ContentString);
					SmartSlydr.Access_Token = Parse_Data_Substring(response.ContentString, "", "\"access_token\":\"", "\"");
					Debug_Message("Refresh_Access_Token", "Access Token = " + SmartSlydr.Access_Token);
					return true;
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "SmartSlydr - Refresh_Access_Token - Error Retreiving Access Tokens" + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return false;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Device_List	-	Gets the list of devices associated with an account
		//                      and print to console
		// 
		//****************************************************************************************
		public void Get_Device_List()
		{
			HttpsClient client = null;

			Refresh_Access_Token();

			#region Create url
			//Create url
			string url = "https://34yl6ald82.execute-api.us-east-2.amazonaws.com/prod/devices";
			Debug_Message("Get_Devices_List", "URL: " + url);
			#endregion

			#region Get List of Devices
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Header.SetHeaderValue("Authorization", SmartSlydr.Access_Token);
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SmartSlydr - Get_Devices_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}
				else
				{
					#region Parse List of Devices
					Debug_Message("Get_Devices_List", "response.ContentString: " + response.ContentString);
					Smart_Slydr_Devices Devices = JsonConvert.DeserializeObject<Smart_Slydr_Devices>(response.ContentString);

					//Get devices from returned json
					if ((Devices != null) && (Devices.room_lists != null))
					{
						//Loop through list
						for (int i = 0; i < Devices.room_lists.Count; i++)
						{
							for (int j = 0; j < Devices.room_lists[i].device_list.Count; j++)
							{
								CrestronConsole.PrintLine("SmartSlydr - Room Name = " + Devices.room_lists[i].room_name + ", Device Name = " + Devices.room_lists[i].device_list[j].devicename + ", Device ID = " + Devices.room_lists[i].device_list[j].device_id);
							}
						}
					}
					else
					{
						string err = "SmartSlydr - Get_Devices_List - No devices found in json: " + response.ContentString;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
						return;
					}
					#endregion
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "SmartSlydr - Get_Devices_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Position	-	Set door position, 0 to 100
		// 
		//****************************************************************************************
		public void Set_Position(string Device_ID, ushort Position)
		{
			HttpsClient client = null;

			#region Error Checking
			if ((Position > 100) && (Position != 200))
			{
				Debug_Message("Set_Position", "Error - Position out of range: " + Position);
				return;
			}
			#endregion

			Refresh_Access_Token();

			#region Create url
			//Create url
			string url = "https://34yl6ald82.execute-api.us-east-2.amazonaws.com/prod/operation";
			Debug_Message("Set_Position", "URL: " + url);
			#endregion

			#region Create JSON
			string json = "{\"setcommands\":[{\"device_id\":\"" + Device_ID + "\",\"commands\":[{\"key\":\"position\",\"value\":" + Position + "}]}]}";
			Debug_Message("Set_Position", "json = " + json);
			#endregion

			#region Set Position
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Header.SetHeaderValue("Authorization", SmartSlydr.Access_Token);
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SmartSlydr - Set_Position - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return;
				}
				else
				{
					Debug_Message("Set_Position", "response.ContentString: " + response.ContentString);
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "SmartSlydr - Set_Position - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Current_Position	-	Get current door position, 0 to 100
		// 
		//****************************************************************************************
		public short Get_Current_Position(string Device_ID)
		{
			HttpsClient client = null;

			Refresh_Access_Token();

			#region Create url
			//Create url
			string url = "https://34yl6ald82.execute-api.us-east-2.amazonaws.com/prod/operation/get";
			Debug_Message("Get_Current_Position", "URL: " + url);
			#endregion

			#region Create JSON
			string json = "{\"commands\":[{\"device_id\":\"" + Device_ID + "\",\"command\":\"position\"}]}";
			Debug_Message("Get_Current_Position", "json = " + json);
			#endregion

			#region Get Position
			try
			{
				#region Make Request
				//Create http client
				client = new HttpsClient();
				//client.Verbose = true;
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Header.SetHeaderValue("Authorization", SmartSlydr.Access_Token);
				request.Header.AddHeader(new HttpsHeader("Accept", "*/*"));

				//Get response
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "SmartSlydr - Get_Current_Position - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -1;
				}
				else
				{
					Debug_Message("Get_Current_Position", "response.ContentString: " + response.ContentString);
					Get_Status_Response Response_Info = JsonConvert.DeserializeObject<Get_Status_Response>(response.ContentString);
					return Convert.ToInt16(Response_Info.response[0].position);
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "SmartSlydr - Get_Current_Position - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -1;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("SmartSlydr-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("SmartSlydr-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("SmartSlydr-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("SmartSlydr-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("SmartSlydr-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("SmartSlydr-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					SmartSlydr.Debug = Debug_Options.None;
					break;

				case 1:
					SmartSlydr.Debug = Debug_Options.Console;
					break;

				case 2:
					SmartSlydr.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					SmartSlydr.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("SmartSlydr - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("SmartSlydr - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	public class Response_Detail
	{
		public int position { get; set; }
		public string device_id { get; set; }
		public string status { get; set; }
	}

	public class Get_Status_Response
	{
		public int statusCode { get; set; }
		public List<Response_Detail> response { get; set; }
	}

	public class DeviceList
	{
		public string device_id { get; set; }
		public string devicename { get; set; }
		public string petpass { get; set; }
		public string room_name { get; set; }
		public string room_id { get; set; }
		public int wlansignal { get; set; }
		public int temperature { get; set; }
		public int humidity { get; set; }
		public int position { get; set; }
		public string error { get; set; }
		public string status { get; set; }
	}

	public class RoomList
	{
		public string room_name { get; set; }
		public List<DeviceList> device_list { get; set; }
	}

	public class Smart_Slydr_Devices
	{
		public int statusCode { get; set; }
		public List<RoomList> room_lists { get; set; }
	}
}
